<?php
declare(strict_types=1);

namespace App\Config;

use PDO;
use PDOException;

class LibraryConfig {
    private string $host = 'localhost';
    private string $db_name = 'library';
    private string $username = 'root';
    private string $password = '';

    public function connect(): PDO {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4";
            return new PDO($dsn, $this->username, $this->password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new RuntimeException("Database connection failed: " . $e->getMessage());
        }
    }
}