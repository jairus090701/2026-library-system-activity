<?php

require_once __DIR__ . '/../vendor/autoload.php';

use App\Repository\BookRepository;
use App\Repository\StudentRepository;
use App\Repository\BorrowRecordRepository;

$bookRepository = new BookRepository();
$studentRepository = new StudentRepository();
$borrowRecordRepository = new BorrowRecordRepository();

$books = $bookRepository->getAll();
$students = $studentRepository->getAll();
$borrowRecords = $borrowRecordRepository->getAll();

?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Library System</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="container">
            <h1>Library System</h1>

            <div class="section">
                <h2>Books</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Author</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($book->getId()); ?></td>
                                <td><?php echo htmlspecialchars($book->getTitle()); ?></td>
                                <td><?php echo htmlspecialchars($book->getAuthor()); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="section">
                <h2>Students</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student->getId()); ?></td>
                                <td><?php echo htmlspecialchars($student->getName()); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="section">
                <h2>Borrow Records</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                        <th>Student ID</th>
                            <th>Book ID</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($borrowRecords as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record->getId()); ?></td>
                                <td><?php echo htmlspecialchars($record->getStudentId()); ?></td>
                                <td><?php echo htmlspecialchars($record->getBookId()); ?></td>
                                <td><?php echo htmlspecialchars($record->getDate()->format('Y-m-d')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
    </html>
