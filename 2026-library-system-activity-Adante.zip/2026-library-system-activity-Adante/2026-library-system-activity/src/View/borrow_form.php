<?php
declare(strict_types=1);

require_once __DIR__ . "/../../vendor/autoload.php";

use App\Repository\BookRepository;

$bookRepository = new BookRepository();
$books = $bookRepository->getAllBooks();
?>

<h2>Books</h2>
<ul>
    <?php foreach ($books as $book): ?>
        <li><?= htmlspecialchars($book->getTitle()) ?> by <?= htmlspecialchars($book->getAuthor()) ?></li>
    <?php endforeach; ?>
</ul>