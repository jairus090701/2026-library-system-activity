<?php
declare(strict_types=1);

require_once __DIR__ . "/../../vendor/autoload.php";

use App\Repository\BookRepository;

$bookRepository = new BookRepository();
$books = $bookRepository->getAllBooks();
?>

<h1>Book List</h1>
<ul>
    <?php foreach ($books as $book): ?>
        <li><?php echo htmlspecialchars($book->getTitle()); ?> by <?php echo htmlspecialchars($book->getAuthor()); ?></li>
    <?php endforeach; ?>
</ul>