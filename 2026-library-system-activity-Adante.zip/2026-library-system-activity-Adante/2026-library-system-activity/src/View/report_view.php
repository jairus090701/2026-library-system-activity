<?php
declare(strict_types=1);

require_once __DIR__ . "/../../vendor/autoload.php";

use App\Repository\BorrowRepository;

$borrowRepository = new BorrowRepository();
$borrowedBooks = $borrowRepository->getBorrowedBooks();
?>
<h1>Borrowed Books Report</h1>
<table border="1"> 
    <tr> 
        <th>Student Name</th> 
        <th>Book Title</th> 
        <th>Author</th> 
        <th>Date Borrowed</th> 
    </tr> 
    <?php foreach ($borrowedBooks as $record): ?> 
    <tr> 
        <td><?= htmlspecialchars($record['student_name']) ?></td> 
        <td><?= htmlspecialchars($record['title']) ?></td> 
        <td><?= htmlspecialchars($record['author']) ?></td> 
        <td><?= htmlspecialchars($record['date']) ?></td> 
    </tr> 
    <?php endforeach; ?> 
</table> 