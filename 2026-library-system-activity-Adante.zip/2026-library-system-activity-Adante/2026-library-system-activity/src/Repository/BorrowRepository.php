<?php
declare(strict_types=1);

namespace App\Repository;

use App\Config\DatabaseConfig;

class BorrowRepository {
    private \PDO $conn;

    public function __construct() {
        $db = new DatabaseConfig();
        $this->conn = $db->connect();
    }

    public function getBorrowedBooks(): array {
        $stmt = $this->conn->query("
            SELECT s.name as student_name, b.title, b.author, br.date
            FROM borrow_records br
            JOIN students s ON br.student_id = s.id
            JOIN books b ON br.book_id = b.id
        ");
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}