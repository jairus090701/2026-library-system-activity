<?php
declare(strict_types=1);

namespace App\Repository;

use App\Config\DatabaseConfig;
use App\Entity\Book;

class BookRepository {
    private \PDO $conn;

    public function __construct() {
        $db = new DatabaseConfig();
        $this->conn = $db->connect();
    }

    public function getAllBooks(): array {
        $stmt = $this->conn->query("SELECT * FROM books");
        $books = [];
        while ($row = $stmt->fetch(\PDO::FETCH_ASSOC)) {
            $books[] = Book::fromArray($row);
        }
        return $books;
    }

    public function addBook(Book $book): bool {
        $stmt = $this->conn->prepare("INSERT INTO books (title, author) VALUES (?, ?)");
        return $stmt->execute([$book->getTitle(), $book->getAuthor()]);
    }
}