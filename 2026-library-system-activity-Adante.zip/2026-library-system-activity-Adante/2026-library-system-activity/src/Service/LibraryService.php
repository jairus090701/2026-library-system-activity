<?php
declare(strict_types=1);

namespace App\Service;

use App\Repository\BookRepository;
use App\Repository\BorrowRepository;
use App\Entity\Book;

class LibraryService {
    private BookRepository $bookRepo;
    private BorrowRepository $borrowRepo;

    public function __construct() {
        $this->bookRepo = new BookRepository();
        $this->borrowRepo = new BorrowRepository();
    }

    public function showBooks(): array {
        return $this->bookRepo->getAllBooks();
    }

    public function addBook(string $title, string $author): bool {
        $book = new Book(0, $title, $author);
        return $this->bookRepo->addBook($book);
    }

    public function borrow(int $student_id, int $book_id): array {
        return $this->borrowRepo->getBorrowedBooks();
    }

    public function getBorrowedBooks(): array {
        return $this->borrowRepo->getBorrowedBooks();
    }
}