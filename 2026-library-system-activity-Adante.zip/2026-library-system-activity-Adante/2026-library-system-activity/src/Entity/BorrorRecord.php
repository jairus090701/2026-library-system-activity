<?php
declare(strict_types=1);

namespace App\Entity;

class BorrowRecord {
    private int $id;
    private int $student_id;
    private int $book_id;
    private DateTime $date;

    public function __construct(int $id, int $student_id, int $book_id, DateTime $date) {
        $this->setId($id);
        $this->setStudentId($student_id);
        $this->setBookId($book_id);
        $this->date = $date;
    }

    public function getId(): int {
        return $this->id;
    }

    private function setId(int $id): void {
        if ($id <= 0) {
            throw new InvalidArgumentException("ID must be a positive integer");
        }
        $this->id = $id;
    }

    public function getStudentId(): int {
        return $this->student_id;
    }

    public function setStudentId(int $student_id): void {
        if ($student_id <= 0) {
            throw new InvalidArgumentException("Student ID must be a positive integer");
        }
        $this->student_id = $student_id;
    }

    public function getBookId(): int {
        return $this->book_id;
    }

    public function setBookId(int $book_id): void {
        if ($book_id <= 0) {
            throw new InvalidArgumentException("Book ID must be a positive integer");
        }
        $this->book_id = $book_id;
    }

    public function getDate(): DateTime {
        return $this->date;
    }

    public function setDate(DateTime $date): void {
        $this->date = $date;
    }

    public static function fromArray(array $data): self {
        return new self(
            (int)($data['id'] ?? 0),
            (int)($data['student_id'] ?? 0),
            (int)($data['book_id'] ?? 0),
            new DateTime($data['date'] ?? 'now')
        );
    }

    public function toArray(): array {
        return [
            'id' => $this->id,
            'student_id' => $this->student_id,
            'book_id' => $this->book_id,
            'date' => $this->date->format('Y-m-d H:i:s'),
        ];
    }
}