<?php
declare(strict_types=1);

namespace App\Entity;

class Student {
    private int $id;
    private string $name;

    public function __construct(int $id, string $name) {
        $this->setId($id);
        $this->setName($name);
    }

    public function getId(): int {
        return $this->id;
    }

    private function setId(int $id): void {
        if ($id <= 0) {
            throw new InvalidArgumentException("ID must be a positive integer");
        }
        $this->id = $id;
    }

    public function getName(): string {
        return $this->name;
    }

    public function setName(string $name): void {
        if (empty(trim($name))) {
            throw new InvalidArgumentException("Name cannot be empty");
        }
        $this->name = $name;
    }

    public static function fromArray(array $data): self {
        return new self(
            (int)($data['id'] ?? 0),
            $data['name'] ?? ''
        );
    }

    public function toArray(): array {
        return [
            'id' => $this->id,
            'name' => $this->name,
        ];
    }
}