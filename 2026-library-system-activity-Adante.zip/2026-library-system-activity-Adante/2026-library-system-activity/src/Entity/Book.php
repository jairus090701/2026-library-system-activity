<?php
declare(strict_types=1);

namespace App\Entity;

class Book {
    private int $id;
    private string $title;
    private string $author;

    public function __construct(int $id, string $title, string $author) {
        $this->setId($id);
        $this->setTitle($title);
        $this->setAuthor($author);
    }

    public function getId(): int {
        return $this->id;
    }

    private function setId(int $id): void {
        if ($id <= 0) {
            throw new InvalidArgumentException("ID must be a positive integer");
        }
        $this->id = $id;
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function setTitle(string $title): void {
        if (empty(trim($title))) {
            throw new InvalidArgumentException("Title cannot be empty");
        }
        $this->title = $title;
    }

    public function getAuthor(): string {
        return $this->author;
    }

    public function setAuthor(string $author): void {
        if (empty(trim($author))) {
            throw new InvalidArgumentException("Author cannot be empty");
        }
        $this->author = $author;
    }

    public static function fromArray(array $data): self {
        return new self(
            (int)($data['id'] ?? 0),
            $data['title'] ?? '',
            $data['author'] ?? ''
        );
    }

    public function toArray(): array {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'author' => $this->author,
        ];
    }
}